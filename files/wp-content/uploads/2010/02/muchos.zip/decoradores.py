def nombrador(f):
    def inner(*a, **kw):
        print "Ejecutando %s" % f.__name__
        return f(*a, **kw)
    return inner        
    
