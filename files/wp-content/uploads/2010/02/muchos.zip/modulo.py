def a():
    pass
    
def b():
    print 42
    
def c():
    a()
    b()
    
import inspect
from decoradores import nombrador

for n,v in locals().items():
   if inspect.isfunction(v) and n != 'nombrador':
       locals()[n] = nombrador(v)
       
if __name__ == '__main__':
    a()
    b()
    c()       
